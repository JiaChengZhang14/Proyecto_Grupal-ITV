create
    definer = root@localhost procedure updateTrabajadorEncriptandoContraseña(IN id_trabajadorP int, IN id_itvP int,
                                                                             IN nombreP varchar(50),
                                                                             IN telefonoP char(9),
                                                                             IN emailP varchar(50),
                                                                             IN nombre_usuarioP varchar(50),
                                                                             IN contraseña_usuarioP varchar(50),
                                                                             IN fecha_contratacionP date,
                                                                             IN especialidadP varchar(20),
                                                                             IN salarioP decimal(6, 2),
                                                                             IN id_responsableP int)
begin
    update trabajador set id_itv = id_itvP, nombre = nombreP, telefono = telefonoP, email = emailP, nombre_usuario = nombre_usuarioP,
    contraseña_usuario = MD5(contraseña_usuarioP), fecha_contratacion = fecha_contratacionP, especialidad = especialidadP, salario = salarioP, id_responsable = id_responsableP
    where id_trabajador = id_trabajadorP;
end;

