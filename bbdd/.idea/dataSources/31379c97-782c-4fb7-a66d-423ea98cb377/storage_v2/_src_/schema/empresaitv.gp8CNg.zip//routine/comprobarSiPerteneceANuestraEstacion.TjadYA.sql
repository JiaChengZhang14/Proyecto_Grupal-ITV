create
    definer = root@localhost procedure comprobarSiPerteneceANuestraEstacion(IN fechaInicio date, IN fechaFin date,
                                                                            IN idVehiculo char(7), IN idTrabajador int)
begin
        call listWorkersByStation(3);
        if(idTrabajador IN (listWorkersByStation(3))) THEN
            INSERT INTO citas values (fechaInicio, fechaFin, idVehiculo, idTrabajador);
        end if;
    end;

