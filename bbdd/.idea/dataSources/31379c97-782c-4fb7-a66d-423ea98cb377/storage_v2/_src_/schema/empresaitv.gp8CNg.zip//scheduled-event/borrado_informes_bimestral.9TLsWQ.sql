create definer = root@localhost event borrado_informes_bimestral on schedule
    at '2023-07-31 11:07:25'
    enable
    do
    BEGIN
    DELETE FROM informe;
    END;

