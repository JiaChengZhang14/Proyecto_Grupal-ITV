create
    definer = root@localhost procedure insertarInformeCompleto(IN idInforme int, IN fechaInicio text, IN fechaFin text,
                                                               IN idVehiculo int, IN idTrabajador int,
                                                               IN favorable text, IN frenado decimal(4, 2),
                                                               IN contaminacion decimal(4, 2), IN interior text,
                                                               IN luces text, IN dniPropietario char(9),
                                                               IN nombrePropietario varchar(50),
                                                               IN apellidosPropietario varchar(50),
                                                               IN telefonoPropietario char(9),
                                                               IN emailPropietario varchar(50), IN trabajadorIdItv int,
                                                               IN nombreTrabajador varchar(50),
                                                               IN telefonoTrabajador char(9),
                                                               IN emailTrabajador varchar(50),
                                                               IN nombreUsuario varchar(50),
                                                               IN contraseñaUsuario varchar(50),
                                                               IN fechaContratacion text,
                                                               IN especialidadTrabajador varchar(20),
                                                               IN salarioTrabajador decimal(6, 2), IN idResponsable int,
                                                               IN matriculaVehiculo char(7),
                                                               IN marcaVehiculo varchar(50),
                                                               IN modeloVehiculo varchar(50),
                                                               IN fechaMatriculacionVehiculo text,
                                                               IN fechaUltimaRevisionVehiculo text,
                                                               IN tipoMotorVehiculo varchar(15),
                                                               IN tipoVehiculoVehiculo varchar(15), IN IdItvPedida int)
begin
    if(trabajadorIdItv = IdItvPedida) THEN
			if((SELECT count(*) from propietario where dni = dniPropietario) = 0) then
            INSERT INTO propietario values (dniPropietario, nombrePropietario, apellidosPropietario, telefonoPropietario, emailPropietario);
            else
            UPDATE propietario set nombre = nombrePropietario, apellidos = apellidosPropietario, telefono = telefonoPropietario, email = emailPropietario
            WHERE dni = dniPropietario;
            end if;

            if((SELECT count(*) from vehiculo where id_vehiculo = idVehiculo) = 0) then
            INSERT INTO vehiculo values (idVehiculo, matriculaVehiculo, dniPropietario, marcaVehiculo, modeloVehiculo, fechaMatriculacionVehiculo,
										fechaUltimaRevisionVehiculo, tipoMotorVehiculo, tipoVehiculoVehiculo);
            else
            UPDATE vehiculo set matricula = matriculaVehiculo, id_propietario = dniPropietario, marca = marcaVehiculo, modelo = modeloVehiculo,
								fecha_matriculacion = fechaMatriculacionVehiculo, fecha_ultima_revision = fechaUltimaRevisionVehiculo, tipo_motor = tipoMotorVehiculo,
                                tipo_vehiculo = tipoVehiculoVehiculo
            WHERE id_vehiculo = idVehiculo;
            end if;
            --
            if((SELECT count(*) from trabajador where id_trabajador = idTrabajador) = 0) then
            call insertTrabajadorEncriptandoContraseña(idTrabajador, trabajadorIdItv, nombreTrabajador, telefonoTrabajador, emailTrabajador,
													nombreUsuario, contraseñaUsuario, fechaContratacion, especialidadTrabajador, salarioTrabajador,
                                                    idResponsable);
            else
            call updateTrabajadorEncriptandoContraseña(idTrabajador, trabajadorIdItv, nombreTrabajador, telefonoTrabajador, emailTrabajador,
													nombreUsuario, contraseñaUsuario, fechaContratacion, especialidadTrabajador, salarioTrabajador,
                                                    idResponsable);
            end if;
            INSERT INTO informe values (idInforme, fechaInicio, fechaFin, idVehiculo, idTrabajador, favorable, frenado, contaminacion, interior, luces);
        end if;

    end;

