create
    definer = root@localhost procedure insertTrabajadorEncriptandoContraseña(IN id_trabajador int, IN id_itv int,
                                                                             IN nombre varchar(50), IN telefono char(9),
                                                                             IN email varchar(50),
                                                                             IN nombre_usuario varchar(50),
                                                                             IN contraseña_usuario varchar(50),
                                                                             IN fecha_contratacion date,
                                                                             IN especialidad varchar(20),
                                                                             IN salario decimal(6, 2),
                                                                             IN id_responsable int)
begin
    insert into trabajador values
    (id_trabajador, id_itv, nombre, telefono, email, nombre_usuario, MD5(contraseña_usuario), fecha_contratacion, especialidad, salario, id_responsable);
end;

