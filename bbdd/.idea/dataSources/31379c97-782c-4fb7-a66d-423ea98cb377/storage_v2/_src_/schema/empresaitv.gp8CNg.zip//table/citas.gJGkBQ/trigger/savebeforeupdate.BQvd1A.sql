create definer = root@localhost trigger saveBeforeUpdate
    after update
    on citas
    for each row
begin
        insert into citasBeforeUpdate(fecha_inicio,fecha_final,id_vehiculo,id_trabajador )
            values (old.fecha_inicio, old.fecha_final, old.id_vehiculo, old.id_trabajador) ;
    end;

