create
    definer = root@localhost procedure listWorkersByStation(IN stationId int)
begin
    declare l_last_row_fetched int;
    declare id int;
    declare c1 cursor for select * from trabajador where id_itv = stationId;
    declare continue handler for not found set l_last_row_fetched = 1;
    set l_last_row_fetched = 0;
    open c1;
    bucle: LOOP
        fetch  c1 into id;
        if l_last_row_fetched =1 then leave bucle;
        end if;
    end loop bucle;
    close c1;
    select * from Trabajador where id_trabajador = id;
end;

