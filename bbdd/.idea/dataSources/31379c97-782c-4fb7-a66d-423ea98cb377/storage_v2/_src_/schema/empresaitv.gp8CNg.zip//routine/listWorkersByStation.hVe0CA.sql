create
    definer = root@localhost procedure listWorkersByStation(IN stationId int)
begin
    declare l_last_row_fetched int;
    declare idTrabajador, idItv int;
    declare nombreTrabajador varchar(50);
    declare telefonoTrabajador char(9);
    declare c1 cursor for select id_trabajador, id_itv, nombre, telefono from trabajador where id_itv = stationId;
    declare continue handler for not found set l_last_row_fetched = 1;
    set l_last_row_fetched = 0;
    open c1;
    repeat
        fetch c1 into idTrabajador, idItv, nombreTrabajador, telefonoTrabajador;
        select idTrabajador, idItv, nombreTrabajador, telefonoTrabajador;
    until l_last_row_fetched = 1 end repeat;
    close c1;
end;

