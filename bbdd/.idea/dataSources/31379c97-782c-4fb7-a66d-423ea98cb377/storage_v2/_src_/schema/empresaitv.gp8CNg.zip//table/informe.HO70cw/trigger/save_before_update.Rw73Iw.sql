create definer = root@localhost trigger save_before_update
    after update
    on informe
    for each row
begin
        insert into informesBeforeUpdate(id_informe, fecha_inicio, fecha_final, id_vehiculo, id_trabajador, favorable, frenado, contaminacion, interior, luces)
            values (old.id_informe, old.fecha_inicio, old.fecha_final, old.id_vehiculo, old.id_trabajador, old.favorable, old.frenado, old.contaminacion,
					old.interior, old.luces) ;
    end;

